#include <iostream>
#include <string>

int main() {
    double result, x, y, z;

    std::cin >> x;
    std::cin >> y;
    std::cin >> z;

    result = (x + y) - z;

    std::cout << result;
}