#include <iostream>
#include <string>

int main() {
    std::cout << "Hello World!";
    return 0;
}