#include <iostream>
#include <string>

int main() {
    std::string input;
    std::cin >> input;
    std::cout << "Hello " << input << "!";
    return 0;
}